import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUIchangeGoal extends JFrame {
    private ArrayList<account> accounts;
    private int selectedFamilyId;
    private String selectedChildName;
    private int currentGoal;

    private JLabel currentGoalLabel;
    private JLabel currentGoalText;
    private JTextField newGoalField;
    private JButton okButton;
    private JButton backButton;

    public GUIchangeGoal(ArrayList<account> accounts, int familyId, String childName) {
        this.accounts = accounts;
        this.selectedFamilyId = familyId;
        this.selectedChildName = childName;

        // Set the page
        setTitle("Change Goal");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Make the elements in the center

        // 调用 showAccount 方法获取目标值并赋给 currentGoal
        ArrayList<account> accountList = AccountReader.showAccount(selectedFamilyId, selectedChildName);
        currentGoal = accountList.get(0).getGoal();

        // 使用 GridBagLayout 布局管理器
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(50, 5, 5, 5); // 设置组件之间的间距

        // 添加顶部标签
        JLabel titleLabel = new JLabel("Set New Goal");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // 设置字体样式
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // 横跨两列
        gbc.anchor = GridBagConstraints.NORTH;
        add(titleLabel, gbc);

        // 创建界面组件
        currentGoalLabel = new JLabel("Current goal:");
        currentGoalLabel.setFont(new Font("Arial", Font.BOLD, 18));
        currentGoalText = new JLabel(" " + currentGoal);
        currentGoalText.setFont(new Font("Arial", Font.BOLD, 18));
        newGoalField = new JTextField(10);
        okButton = new JButton("OK");
        okButton.setFont(new Font("Arial", Font.BOLD, 18));
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 18));
        JLabel newGoalLabel = new JLabel("New goal:");
        newGoalLabel.setFont(new Font("Arial", Font.BOLD, 18)); // 设置字体样式
        newGoalField.setPreferredSize(new Dimension(20, 30));
        gbc.gridy = 1;
        gbc.gridwidth = 2; // 横跨两列
        gbc.weighty = 1.0; // 设置垂直方向上的权重，使空白区域可以扩展
        add(Box.createVerticalStrut(20), gbc);

        // 设置组件位置
        gbc.gridy = 2;
        gbc.gridwidth = 1; // 恢复默认值
        add(currentGoalLabel, gbc);

        gbc.gridy = 2;
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        add(currentGoalText, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        add(newGoalLabel, gbc);

        gbc.gridx = -1;
        add(newGoalField, gbc);

        gbc.gridx = -1;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(okButton, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(backButton, gbc);

        // 添加事件监听器
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newGoalText = newGoalField.getText();
                if (!newGoalText.isEmpty()) {
                    if (newGoalText.matches("\\d+")) {
                        double newGoal = Double.parseDouble(newGoalText);
                        if(newGoal < 100000){
                            int newGoal0 = (int)newGoal;
                            changeAccountDetail.changeGoal(selectedFamilyId, selectedChildName, newGoal0);
                            JOptionPane.showMessageDialog(null, "Goal changed successfully!");
                        }else {
                            JOptionPane.showMessageDialog(null, "Goal should be less than 100000!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Goal should be a positive number!", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a new goal!");
                }
            }
        });

        backButton.addActionListener(e -> {
            new GUIChild(familyId, childName, "child").setVisible(true);
            this.setVisible(false);
        });

        // 显示界面
        setVisible(true);
    }
}
