import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUIlauchtasks extends JFrame {

    private JTextField childNameField, taskNameField, bonusField;

    private ArrayList<account> familyaccount;

    private user User;

    public GUIlauchtasks(user user0) {

        this.User = user0;

        this.familyaccount = AccountReader.showFamilyAccount(User.getFamilyId());


        setTitle("New Task");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(0, 1));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("New Task");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titlePanel.add(titleLabel);
        add(titlePanel);

        JLabel childNameLabel = new JLabel("Child name:");
        childNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        childNameField = new JTextField(20);
        JPanel childNamePanel = new JPanel();
        childNamePanel.add(childNameLabel);
        childNamePanel.add(childNameField);
        add(childNamePanel);

        JLabel taskNameLabel = new JLabel("Task Name:");
        taskNameField = new JTextField(20);
        taskNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        JPanel taskNamePanel = new JPanel();
        taskNamePanel.add(taskNameLabel);
        taskNamePanel.add(taskNameField);
        add(taskNamePanel);

        JLabel bonusLabel = new JLabel("Bonus:");
        bonusField = new JTextField(20);
        bonusLabel.setFont(new Font("Arial", Font.BOLD, 18));
        JPanel bonusPanel = new JPanel();
        bonusPanel.add(bonusLabel);
        bonusPanel.add(bonusField);
        add(bonusPanel);

        JButton launchButton = new JButton("Launch");
        launchButton.setFont(new Font("Arial", Font.BOLD, 18));
        JPanel launchPanel = new JPanel();
        launchPanel.add(launchButton);
        add(launchPanel);

        JButton homeButton = new JButton("Home");
        JPanel homePanel = new JPanel();
        homeButton.setFont(new Font("Arial", Font.BOLD, 18));
        homePanel.add(homeButton);
        add(homePanel);

        launchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String childName = childNameField.getText();
                String taskname = taskNameField.getText();
                String bonus = bonusField.getText();
                if(!(childName.isEmpty()) && !(taskname.isEmpty()) && !(bonus.isEmpty())){
                    if (checkChildName(childName)) {
                        if (bonus.matches("\\d+")) {
                            double bonusInt = Double.parseDouble(bonus);
                            if(bonusInt < 100000){
                                int bonusInt0 = (int)bonusInt;
                                parent p = new parent(User.getFamilyId(),User.getName(),"parent");
                                p.releaseTask(taskname,bonusInt0,childName);
                                JOptionPane.showMessageDialog(null, "You have successfully published the mission!", "Purchase Status", JOptionPane.INFORMATION_MESSAGE);
                            }else {
                                JOptionPane.showMessageDialog(GUIlauchtasks.this, "Bonus should less than 100000 yuan!", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                        } else {
                            JOptionPane.showMessageDialog(GUIlauchtasks.this, "Please enter the correct bonus!", "Error", JOptionPane.ERROR_MESSAGE);
                        }


                    } else {
                        JOptionPane.showMessageDialog(GUIlauchtasks.this, "The child name does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }else {
                    JOptionPane.showMessageDialog(GUIlauchtasks.this, "Please enter the full content!", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        homeButton.addActionListener(e -> {
            new GUIParent(User.getFamilyId(),User.getName(), "parent").setVisible(true);
            this.setVisible(false);
        });

        setVisible(true);
    }



    // Dummy method to simulate checking if child name exists
    private boolean checkChildName(String childName) {

        for (account u : familyaccount) {
            if(u.getChildName().equals(childName)){
                return true;
            }
        }
        // Simulate that the child name exists in UserReader class
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            user user = new user(); // you need to create a User object or pass it here
            new GUIlauchtasks(user).setVisible(true);
        });
    }
}