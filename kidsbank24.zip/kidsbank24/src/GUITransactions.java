import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.util.*;

public class GUITransactions extends JFrame {
    private JScrollPane scrollPane;
    private JLabel titleLabel;
    private JPanel transHeader;
    private JButton homeButton;

    public void initialize(int familyId, String name, String identity) {
        this.setTitle("submit tasks and get bonus!");
        this.setSize(700, 450);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.getContentPane().setLayout(new BorderLayout());

        // 创建并设置任务标题标签，添加适当的边距，此处分为parent和child两个显示效果
        this.transHeader = new JPanel(new GridBagLayout());
        if (identity.equals("parent")) {
            GridBagConstraints parentConstraints = new GridBagConstraints();
            parentConstraints.fill = GridBagConstraints.HORIZONTAL;
            parentConstraints.weightx = 1;
            parentConstraints.insets = new Insets(5, 5, 5, 5); // [修改] 统一设置内边距以确保对齐

            // 第一行的标题"Tasks"
            parentConstraints.gridy = 0;
            parentConstraints.gridx = 0; // [修改] 调整gridx起始位置以与下面行对齐
            parentConstraints.gridwidth = 3; // [修改] 让标题跨越所有列
            this.titleLabel = new JLabel("Transactions", JLabel.CENTER);
            this.titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
            this.transHeader.add(titleLabel, parentConstraints);

            // 第二行的task表头: childName, reason, change
            parentConstraints.gridy = 1;
            parentConstraints.gridwidth = 1;
            String[] headers = {"childName", "description", "change"};
            for (int i = 0; i < headers.length; i++) {
                parentConstraints.gridx = i;
                JLabel headerLabel = new JLabel(headers[i], JLabel.CENTER);
                headerLabel.setFont(new Font("Arial", Font.PLAIN, 18));
                this.transHeader.add(headerLabel, parentConstraints);
            }
        } else if (identity.equals("child")) {
            GridBagConstraints childConstraints = new GridBagConstraints();
            childConstraints.fill = GridBagConstraints.HORIZONTAL;
            childConstraints.weightx = 1;
            childConstraints.insets = new Insets(5, 5, 5, 5); // [修改] 统一设置内边距以确保对齐

            // 第一行的标题"Tasks"
            childConstraints.gridy = 0;
            childConstraints.gridx = 0; // [修改] 调整gridx起始位置以与下面行对齐
            childConstraints.gridwidth = 2; // [修改] 让标题跨越所有列
            this.titleLabel = new JLabel("Transactions", JLabel.CENTER);
            this.titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
            this.transHeader.add(titleLabel, childConstraints);

            // 第二行的task表头: reason, change
            childConstraints.gridy = 1;
            childConstraints.gridwidth = 1;
            String[] headers = {"reason", "change"};
            for (int i = 0; i < headers.length; i++) {
                childConstraints.gridx = i;
                JLabel headerLabel = new JLabel(headers[i], JLabel.CENTER);
                headerLabel.setFont(new Font("Arial", Font.PLAIN, 18));
                this.transHeader.add(headerLabel, childConstraints);
            }
        }
        this.getContentPane().add(BorderLayout.NORTH, this.transHeader);

        if (identity.equals("parent")) {
            this.getContentPane().add(BorderLayout.CENTER, this.createScrollPane(familyId));
        } else if (identity.equals("child")){
            this.getContentPane().add(BorderLayout.CENTER, this.createScrollPane(familyId, name));
        }

        // 创建按钮并设置边距和大小
        homeButton = new JButton("Home");
        homeButton.setPreferredSize(new Dimension(100, 40));  // 设置按钮的首选大小
        JPanel buttonPanel = new JPanel();  // 使用JPanel来控制按钮的布局
        buttonPanel.setBorder(new EmptyBorder(10, 50, 10, 50));  // 为按钮面板添加边距
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));  // 居中布局
        homeButton.setFont(new Font("Arial", Font.BOLD, 18));
        buttonPanel.add(homeButton);
        // 暂定逻辑：返回kid/parent主界面<=>隐藏transaction界面
        homeButton.addActionListener(e -> {
            if (identity.equals("child")) {
                new GUIChild(familyId, name, "child").setVisible(true);
                this.setVisible(false);
            } else if (identity.equals("parent")) {
                new GUIParent(familyId, name, "parent").setVisible(true);
                this.setVisible(false);
            }
        });
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    // 家长功能
    public JScrollPane createScrollPane(int familyId) {
        JPanel containerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL; // 水平填充
        constraints.insets = new Insets(5, 5, 5, 5); // 设置每个格子的 上左下右 边距
        constraints.weightx = 1; // 横向缩放比，1代表格子大小对齐任意大小的窗口
        constraints.weighty = 1; // 纵向缩放比，同上

        // 调用recordReader类的方法，获取该家庭的全部record信息
        ArrayList<Record> records = RecordReader.getRecordInfoAll(familyId);
        boolean hasRecord = false; // 标志，判断该家庭是否有记录

        // 绘制全部transaction信息的表单
        for (Record r : records) {
            if (r.getFamilyId() == familyId) {
                hasRecord = true;
                // childName
                constraints.gridy = GridBagConstraints.RELATIVE;
                constraints.gridx = 0;
                constraints.anchor = GridBagConstraints.CENTER;
                JLabel childNameLabel = new JLabel(r.getName(), JLabel.CENTER);
                childNameLabel.setFont(new Font("微软雅黑", Font.PLAIN, 18));
                containerPanel.add(childNameLabel, constraints);

                // description
                constraints.gridx = 1;
                constraints.anchor = GridBagConstraints.CENTER;
                JLabel descriptionLabel = new JLabel(r.getType(), JLabel.CENTER);
                descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 18));
                containerPanel.add(descriptionLabel, constraints);

                // change
                constraints.gridx = 2;
                constraints.anchor = GridBagConstraints.CENTER;
                JLabel changeLabel = new JLabel();
                if (r.getChangeMoney() > 0) {
                    changeLabel.setText("+" + Integer.toString(r.getChangeMoney()));
                    changeLabel.setForeground(Color.RED);

                } else if (r.getChangeMoney() <= 0) {
                    changeLabel.setText(Integer.toString(r.getChangeMoney()));
                    changeLabel.setForeground(Color.GREEN);
                }
                changeLabel.setHorizontalAlignment(JLabel.CENTER);
                changeLabel.setFont(new Font("Arial", Font.PLAIN, 18));
                containerPanel.add(changeLabel, constraints);
            }
        }

        // 创建纵向滚动的列表，大小为400×300 & 边距 上10，左10，下10，右0
        JScrollPane scrollPane = new JScrollPane(containerPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));

        // 没有记录，显示一行字提示
        if(!hasRecord) {
            containerPanel.removeAll();
            JLabel reminderLabel = new JLabel("No Records");
            reminderLabel.setFont(new Font("Arial", Font.ITALIC, 30));
            reminderLabel.setHorizontalAlignment(JLabel.CENTER);
            containerPanel.setLayout(new BorderLayout());
            containerPanel.add(reminderLabel, BorderLayout.CENTER);
            scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));
        }
        return scrollPane;
    }

    // 小孩功能
    public JScrollPane createScrollPane(int familyId, String name) {
        JPanel containerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL; // 水平填充
        constraints.insets = new Insets(5, 5, 5, 5); // 设置每个格子的 上左下右 边距
        constraints.weightx = 1; // 横向缩放比，1代表格子大小对齐任意大小的窗口
        constraints.weighty = 1; // 纵向缩放比，同上

        // 调用recordReader类的方法，获取该小孩的全部record信息
        ArrayList<Record> records = RecordReader.getRecordInfoAll(familyId);
        boolean hasRecord = false; // 标志，判断该家庭是否有记录

        // 绘制全部transaction信息的表单
        for (Record r : records) {
            if (r.getName().equals(name)) {
                hasRecord = true;
                // description
                constraints.gridx = 0;
                constraints.anchor = GridBagConstraints.CENTER;
                JLabel descriptionLabel = new JLabel(r.getType(), JLabel.CENTER);
                descriptionLabel.setFont(new Font("微软雅黑", Font.PLAIN, 18));
                containerPanel.add(descriptionLabel, constraints);

                // change
                constraints.gridx = 1;
                constraints.anchor = GridBagConstraints.CENTER;
                JLabel changeLabel = new JLabel();
                if (r.getChangeMoney() > 0) {
                    changeLabel.setText("+" + Integer.toString(r.getChangeMoney()));
                    changeLabel.setForeground(Color.RED);

                } else if (r.getChangeMoney() <= 0) {
                    changeLabel.setText(Integer.toString(r.getChangeMoney()));
                    changeLabel.setForeground(Color.GREEN);
                }
                changeLabel.setHorizontalAlignment(JLabel.CENTER);
                changeLabel.setFont(new Font("Arial", Font.PLAIN, 18));
                containerPanel.add(changeLabel, constraints);
            }
        }

        // 创建纵向滚动的列表，大小为400×300 & 边距 上10，左10，下10，右0
        JScrollPane scrollPane = new JScrollPane(containerPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));

        // 没有记录，显示一行字提示
        if(!hasRecord) {
            containerPanel.removeAll();
            JLabel reminderLabel = new JLabel("No Records");
            reminderLabel.setFont(new Font("Arial", Font.BOLD, 30));
            reminderLabel.setHorizontalAlignment(JLabel.CENTER);
            containerPanel.setLayout(new BorderLayout());
            containerPanel.add(reminderLabel, BorderLayout.CENTER);
            scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));
        }

        return scrollPane;
    }

    public GUITransactions(int familyId, String name, String identity) {
        this.initialize(familyId, name, identity);
    }

    // main仅用于测试
    public static void main(String[] args) {
        // 给出了调用的一般顺序：实例化一个GUITransactions对象，为initialize()传入参数，setVisible
        GUITransactions myTrans = new GUITransactions(51249745, "Fanzizhou", "parent");
        myTrans.setVisible(true);
    }
}
