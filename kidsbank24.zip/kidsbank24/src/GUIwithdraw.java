import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUIwithdraw extends JFrame {
    private int familyId;
    private String childName;
    private String identity;
    private JLabel titleLabel,withdrawLabel;
    private JTextField withdrawField;
    private JButton okButton;
    private JButton backButton;

    private int goal;
    private int currentAccount;
    private int savingAccount;

    private JLabel savingAccountLabel;
    private JLabel currentAccountLabel;
    private JLabel goalLabel;

    public GUIwithdraw(int familyId, String childName, String identity) {
        this.familyId = familyId;
        this.childName = childName;
        this.identity = identity;

        ArrayList<account> accounts = AccountReader.showAccount(familyId, childName);
        for (account acc : accounts) {
            this.goal = acc.getGoal();
            this.currentAccount = acc.getCurrentAccount();
            this.savingAccount = acc.getSavingAccount();
        }

        setTitle("Withdraw");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 5, 5, 5);

        titleLabel = new JLabel("Withdraw");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(titleLabel, gbc);

        // Add labels to show account details
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 5, 5, 5);
        savingAccountLabel = new JLabel("Saving Account: ¥" + savingAccount);
        savingAccountLabel.setFont(new Font("Arial", Font.BOLD, 18));
        currentAccountLabel = new JLabel("Current Account: ¥" + currentAccount);
        currentAccountLabel.setFont(new Font("Arial", Font.BOLD, 18));
        goalLabel = new JLabel("Goal: ¥" + goal);
        goalLabel.setFont(new Font("Arial", Font.BOLD, 18));

        JPanel accountPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        accountPanel.add(savingAccountLabel);
        accountPanel.add(currentAccountLabel);
        accountPanel.add(goalLabel);

        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(accountPanel, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        add(Box.createVerticalStrut(20), gbc);

        withdrawField = new JTextField(10);
        okButton = new JButton("OK");
        okButton.setFont(new Font("Arial", Font.BOLD, 18));
        backButton = new JButton("Home");
        backButton.setFont(new Font("Arial", Font.BOLD, 18));

        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        withdrawLabel =new JLabel("Withdraw amount:");
        withdrawLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(withdrawLabel , gbc);


        gbc.gridx = 1;
        add(withdrawField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(okButton, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(backButton, gbc);

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String withdrawAmountText = withdrawField.getText();
                if (!withdrawAmountText.isEmpty()) {
                    if (withdrawAmountText.matches("\\d+")) {
                        double withdrawAmount = Double.parseDouble(withdrawAmountText);
                        account Account = new account();
                        ArrayList<account> accountList = AccountReader.showAccount(familyId, childName);
                        for (account t : accountList) {
                            Account = t;
                        }
                        if (withdrawAmount < Integer.MAX_VALUE) {
                            if (withdrawAmount == 0) {
                                JOptionPane.showMessageDialog(null, "Please enter a withdraw amount!");
                            } else if (withdrawAmount <= Account.getSavingAccount()) {
                                Child child = new Child(familyId, childName, identity);
                                child.withdraw((int) withdrawAmount);
                                savingAccount -= withdrawAmount;
                                currentAccount += withdrawAmount;
                                updateLabels();
                                JOptionPane.showMessageDialog(null, "Withdraw successful! And now, your saving account is ¥" +
                                        savingAccount + ", your current account is ¥" + currentAccount + ".");
                            } else if (withdrawAmount > Account.getSavingAccount()) {
                                JOptionPane.showMessageDialog(null, "Your money in Saving Account is not enough!");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Your money in Saving Account is not enough!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Withdraw Amount should be a positive number!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a withdraw amount!");
                }
            }
        });

        backButton.addActionListener(e -> {
            new GUIChild(familyId, childName, "child").setVisible(true);
            this.setVisible(false);
        });

        setVisible(true);
    }

    private void updateLabels() {
        savingAccountLabel.setText("Saving Account: ¥" + savingAccount);
        currentAccountLabel.setText("Current Account: ¥" + currentAccount);
        goalLabel.setText("Goal: ¥" + goal);
    }

    public static void main(String[] args) {
        new GUIwithdraw(1, "2", "child");
    }
}
