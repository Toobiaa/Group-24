import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.util.*;

public class GUITasksParent extends JFrame {
    private JScrollPane scrollPane;
    private JLabel taskTitleLabel;
    private JPanel taskHeader;
    private JButton homeButton;
    private int FamilyId;
    private String Name;


    public void initialize(int familyId, String name) {
        this.Name = name;
        this.FamilyId = familyId;
        this.setTitle("view tasks and give rewards");
        this.setSize(900, 400);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.getContentPane().setLayout(new BorderLayout());

        // 最上面的部分，由一个"Task"和表头组成，使用GridBagLayout以实现精确布局
        this.taskHeader = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1;
        constraints.insets = new Insets(5, 5, 5, 5); // [修改] 统一设置内边距以确保对齐

        // 第一行的标题"Tasks"
        constraints.gridy = 0;
        constraints.gridx = 0; // [修改] 调整gridx起始位置以与下面行对齐
        constraints.gridwidth = 5; // [修改] 让标题跨越所有列
        this.taskTitleLabel = new JLabel("Tasks", JLabel.CENTER);
        this.taskTitleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        // taskTitleLabel.setBorder(new EmptyBorder(10, 0, 10, 0));
        taskHeader.add(taskTitleLabel, constraints);

        // 第二行的task表头: childName, taskName, bonus, action, status
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        String[] headers = {"childName", "taskName", "bonus", "action   ", "status"};
        for (int i = 0; i < headers.length; i++) {
            constraints.gridx = i;
            JLabel headerLabel = new JLabel(headers[i], JLabel.CENTER);
            headerLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            taskHeader.add(headerLabel, constraints);
        }
        this.getContentPane().add(BorderLayout.NORTH, taskHeader);

        this.updateTasksUI(familyId);

        // 创建按钮并设置边距和大小
        homeButton = new JButton("Home");
        homeButton.setPreferredSize(new Dimension(100, 40));  // 设置按钮的首选大小
        homeButton.setFont(new Font("Arial", Font.BOLD, 18));
        JPanel buttonPanel = new JPanel();  // 使用JPanel来控制按钮的布局
        //buttonPanel.setBorder(new EmptyBorder(10, 50, 10, 50));  // 为按钮面板添加边距
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));  // 居中布局
        buttonPanel.add(homeButton);
        // 暂定逻辑：返回parent主界面<=>隐藏task界面
        homeButton.addActionListener(e -> {
            new GUIParent(familyId, name, "parent").setVisible(true);
            this.setVisible(false);
        });
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    private void updateTasksUI(int familyId) {
        if (scrollPane != null) {
            this.getContentPane().remove(scrollPane);
        }
        this.scrollPane = this.createScrollPane(familyId);
        this.getContentPane().add(BorderLayout.CENTER, this.scrollPane);
        this.revalidate();
        this.repaint();
    }

    private JScrollPane createScrollPane(int familyId) {
        JPanel containerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL; // 水平填充
        constraints.insets = new Insets(5, 5, 5, 5); // 设置每个格子的 上左下右 边距
        constraints.weightx = 1; // 横向缩放比，1代表格子大小对齐任意大小的窗口
        constraints.weighty = 1; // 纵向缩放比，同上

        // 调用task类的方法，获取该家庭的全部task信息
        ArrayList<task> tasks = task.viewTasks(familyId);

        // 绘制全部任务信息的表单
        for (task t : tasks) {
            constraints.gridy = GridBagConstraints.RELATIVE;
            constraints.gridx = 0;
            constraints.anchor = GridBagConstraints.CENTER;
            JLabel childNameLabel = new JLabel(t.getChildName(), JLabel.CENTER);
            childNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            containerPanel.add(childNameLabel, constraints);

            constraints.gridx = 1;
            constraints.anchor = GridBagConstraints.CENTER;
            JLabel taskNameLabel = new JLabel(t.getTaskName(), JLabel.CENTER);
            taskNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            containerPanel.add(taskNameLabel, constraints);

            constraints.gridx = 2;
            constraints.anchor = GridBagConstraints.CENTER;
            JLabel bonusLabel = new JLabel(Integer.toString(t.getBonus()), JLabel.CENTER);
            bonusLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            containerPanel.add(bonusLabel, constraints);

            constraints.gridx = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            constraints.weightx = 0.3;
            JButton permitButton = new JButton();
            permitButton.setText("Permit");
            permitButton.setPreferredSize(new Dimension(80, 30));
            if (t.isSubmitted()) {
                if (t.isDone()) {
                    permitButton.setForeground(Color.gray);
                    permitButton.setEnabled(false);
                } else {
                    permitButton.setForeground(Color.BLACK);
                }
            } else {
                permitButton.setForeground(Color.gray);
                permitButton.setEnabled(false);
            }
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(permitButton);
            containerPanel.add(buttonPanel, constraints);

            permitButton.addActionListener(e -> {
                parent p = new parent(this.FamilyId,this.Name,"parent");
                p.PermitTask(t.getTaskId());
                this.updateTasksUI(familyId);
            });

            constraints.gridx = 4;
            constraints.anchor = GridBagConstraints.CENTER;
            JLabel statusLabel = new JLabel();
            if (t.isSubmitted()) {
                if (t.isDone()) {
                    statusLabel.setText("Done");
                    statusLabel.setForeground(Color.GREEN);
                } else {
                    statusLabel.setText("Submitted");
                    statusLabel.setForeground(Color.RED);
                }
            } else {
                statusLabel.setText("Not Submitted");
                statusLabel.setForeground(Color.gray);
            }
            statusLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            statusLabel.setHorizontalAlignment(JLabel.CENTER);
            containerPanel.add(statusLabel, constraints);
        }

        // 创建纵向滚动的列表，大小为400×300 & 边距 上10，左80，下10，右0
        JScrollPane scrollPane = new JScrollPane(containerPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));

        // 没有任务，显示一行字提示
        if(tasks.isEmpty()) {
            containerPanel.removeAll();
            JLabel reminderLabel = new JLabel("No Tasks");
            reminderLabel.setFont(new Font("Arial", Font.ITALIC, 30));
            reminderLabel.setHorizontalAlignment(JLabel.CENTER);
            containerPanel.setLayout(new BorderLayout());containerPanel.add(reminderLabel, BorderLayout.CENTER);
            scrollPane.setBorder(new EmptyBorder(10, 0, 10, 0));
        }

        return scrollPane;
    }

    public GUITasksParent(int familyId, String name) {
        this.initialize(familyId, name);
    }

    // main仅用于测试
    public static void main(String[] args) {
        // 给出了调用的一般顺序：实例化一个GUITasksParent对象，为initialize()传入参数，setVisible
        GUITasksParent myTasks = new GUITasksParent(89106409, "明泽");
        myTasks.setVisible(true);
    }
}
